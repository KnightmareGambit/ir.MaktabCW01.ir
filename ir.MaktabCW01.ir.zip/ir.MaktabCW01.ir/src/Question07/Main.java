package Question07;

public class Main {

}

